﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NumericalMethods
{
    public delegate double Function(double x, double y);
    public delegate double FunctionOne(double x);
}
