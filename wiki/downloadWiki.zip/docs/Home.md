**Project Description**
Numerical Methods in C#.

Used in Math Rocks! for Windows Phone.

![Math Rocks! for Windows Phone](Home_http://catalog.zune.net/v3.2/en-US/apps/4884d3f7-b2fd-4be4-9121-8f9ebc3ef871/primaryImage?width=240&height=240&resize=true|http://catalog.zune.net/v3.2/en-US/apps/4884d3f7-b2fd-4be4-9121-8f9ebc3ef871/primaryImage?width=240&height=240&resize=true)

Link in Marketplace:- [http://www.windowsphone.com/en-US/apps/4884d3f7-b2fd-4be4-9121-8f9ebc3ef871](http://www.windowsphone.com/en-US/apps/4884d3f7-b2fd-4be4-9121-8f9ebc3ef871)

### Differential Equations Solving
* Euler Simple  ([http://en.wikipedia.org/wiki/Euler's_method](http://en.wikipedia.org/wiki/Euler's_method))
* Euler Modified  ([http://mat.iitm.ac.in/~sryedida/caimna/ode/euler/ie.html](http://mat.iitm.ac.in/~sryedida/caimna/ode/euler/ie.html))
* Euler Corrected 
* Runge-Kutta 4th precision  ([http://en.wikipedia.org/wiki/Runge-Kutta](http://en.wikipedia.org/wiki/Runge-Kutta))

### Approximation
* Bisection method ([http://en.wikipedia.org/wiki/Bisection_method](http://en.wikipedia.org/wiki/Bisection_method))
* Сhord method  ([http://www.cs.mtu.edu/~shene/COURSES/cs3621/NOTES/INT-APP/PARA-chord-length.html](http://www.cs.mtu.edu/~shene/COURSES/cs3621/NOTES/INT-APP/PARA-chord-length.html))
* Newton's method ([http://en.wikipedia.org/wiki/Newton%27s_method](http://en.wikipedia.org/wiki/Newton%27s_method))

### Integration
* Chebishev's method  ([http://www.pci.uni-heidelberg.de/tc/usr/andreasm/academic/handouthtml/node14.html](http://www.pci.uni-heidelberg.de/tc/usr/andreasm/academic/handouthtml/node14.html))
* Simpson's  method  ([http://en.wikipedia.org/wiki/Simpson's_rule](http://en.wikipedia.org/wiki/Simpson's_rule))
* Trapezium method  ([http://www.brighton-webs.co.uk/maths/inttrap.asp](http://www.brighton-webs.co.uk/maths/inttrap.asp))

### Non Linear Equations Solving
* Newton's method
* Secant method
* Half Division method
* Chord method

### Systems of Linear Equations Solving
* Gauss's methos
* Zeidel's method

### Curves
* Curve
* Histogram

### Interpolation
* Bulirsch Stoer Interpolator
* Lagrange Interpolator
* Neville Interpolator
* Newton Interpolator
* Spline Interpolator

### Matrix Algebra
* Dhb I llegal Dimension
* Dhb Non Symmetric Components
* Dhb Vector
* Jacobi Transformation
* Largest EigenvalueFinder
* Linear Equations
* LUP Decomposition
* Matrix
* Symmetric Matrix

### Optimizing
* Chromosome Manager
* Genetic Optimizer
* Hill Climbing Optimizer
* Maximizing Point
* Maximizing PointFactory
* Maximizing Vector
* Minimizing Point
* Minimizing Point Factory
* Minimizing Vector
* Multi Variable General Optimizer
* Multi Variable Optimizer
* One Variable Function Optimizer
* Optimizing Bracket Finder
* Optimizing Point
* Optimizing Point Factory
* Optimizing Vector
* Simplex Optimizer
* Vector Chromosome Manager
* Vector Genetic Optimizer
* Vector Projected Function

### Regression
* Estimated Polynomial
* Linear Regression
* Polynomial Function
* Polynomial Least Square Fit
* Weighted Point

### Statistics
* Beta Distribution
* Cauchy Distribution
* ChiSquare Distribution
* Exponential Distribution
* Fast Statistical Moments
* Fisher Snedecor Distribution
* Fisher Tippett Distribution
* Fixed Statistical Moments
* Gamma Distribution
* Histogrammed Distribution
* Laplace Distribution
* Log Normal Distribution
* Mitchell Moore Generator
* Normal Distribution
* Offset Distribution Function
* Probability Density Function
* Probability Density With Unknown Distribution
* Random Generator
* Random Integrator
* Scaled Probability Density Function
* Statistical Moments
* Studnt Distribution
* Triangular Distribution
* Uniform Distribution
* Weibull Distribution